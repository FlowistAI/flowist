export type SettingRefAttrs = {
    save: () => void
}
