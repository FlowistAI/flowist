export const Invalid = () => {
    return (
        <div className="text-red-500 text-center text-2xl font-bold">
            BUG: Invalid State
        </div>
    )
}
