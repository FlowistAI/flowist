export type Language = {
    id: string
    name: string
};

export type LangId = Language['id'];
