

export type TextToSpeechSession = {
    id: string
    input: string
    output: string
};

export type TextToSpeechNodeData = {
    id: string
};


