import { Node } from 'reactflow'

export const initNodes: Node[] = [
    // {
    //     id: 'b',
    //     data: { label: 'Node B' },
    //     position: { x: 100, y: 100 },
    // },
]

export const initEdges = [
    // {
    //     id: 'a-b',
    //     source: 'a',
    //     target: 'b',
    // },
]
